function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6lL0qoVY982":
        Script1();
        break;
      case "6dSpHoeMeop":
        Script2();
        break;
      case "64YdhEx6HMB":
        Script3();
        break;
      case "61ToG9Y9bGx":
        Script4();
        break;
      case "6CiRCsd3p82":
        Script5();
        break;
      case "5qwGiaEyrkX":
        Script6();
        break;
      case "6qHbbKlZEkA":
        Script7();
        break;
      case "5f7Afpr0P2t":
        Script8();
        break;
      case "6K28f67gouW":
        Script9();
        break;
      case "6FIVy1QJxWl":
        Script10();
        break;
      case "6JA4hCu3YMZ":
        Script11();
        break;
      case "5Z3Aj0EVBSI":
        Script12();
        break;
      case "5adQG1J9sIy":
        Script13();
        break;
      case "6acmwbDJZ1p":
        Script14();
        break;
      case "5mGiyv2UTgU":
        Script15();
        break;
      case "6FrQsAfQOQc":
        Script16();
        break;
      case "5i9NGvEzfDW":
        Script17();
        break;
      case "5ZUN78dUcdk":
        Script18();
        break;
      case "6NKFgJXA3RT":
        Script19();
        break;
      case "5by9QAPsU4Q":
        Script20();
        break;
      case "5vs8WpvJD53":
        Script21();
        break;
      case "5joLmraxiYj":
        Script22();
        break;
      case "6XQ8vsphShw":
        Script23();
        break;
      case "6eXibiKmKrX":
        Script24();
        break;
      case "6mUCNSyUDMV":
        Script25();
        break;
      case "6b9iPSV4lhv":
        Script26();
        break;
      case "5poR1E0Qxsf":
        Script27();
        break;
      case "6dpQ83Hn5aF":
        Script28();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  const target = object('6bOznPBDfha');
const duration = 750;
const easing = 'ease-out';
const id = '5ziGPj7WT8R';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('63YIBQGiQ7z');
const duration = 500;
const easing = 'ease-out';
const id = '6lLmkuAepMW';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('6IeZdToIrXA');
const duration = 750;
const easing = 'ease-out';
const id = '5aGGT5Z4TSd';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('6iYctgSpVHI');
const duration = 500;
const easing = 'ease-out';
const id = '5pTRDPsgut0';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6SoyoGPmWg0');
const duration = 750;
const easing = 'ease-out';
const id = '6JCLrnGeLB8';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6rkAXMVTEvJ');
const duration = 500;
const easing = 'ease-out';
const id = '6c5LJczjZsR';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('66EjGC7O0A4');
const duration = 750;
const easing = 'ease-out';
const id = '6gx89PKcJVu';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('5aJvvFfweRS');
const duration = 500;
const easing = 'ease-out';
const id = '5V2rxF2pAQJ';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('675tkP9nhBh');
const duration = 500;
const easing = 'ease-out';
const id = '5UhNdx5GMXG';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('6Hk18RFWb8B');
const duration = 500;
const easing = 'ease-out';
const id = '5Y6T7woVOJa';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  player.once(() => {
const target = object('5tDdgnaI6Dz');
const duration = 500;
const easing = 'ease-out';
const id = '6aMOcUmfJhi';
const pulseAmount = 0.1;
const delay = 938;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script12 = function()
{
  const target = object('6qer6HvM3io');
const duration = 750;
const easing = 'ease-out';
const id = '6ZrYLnysmM2';
const shakeAmount = 2;
player.addForTriggers(
id,
target.animate([
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `${shakeAmount}px 0` },
{ translate: '0 0' },
{ translate: `-${shakeAmount}px 0` },
{ translate: '0 0' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  player.once(() => {
const target = object('60a34VZDlUW');
const duration = 500;
const easing = 'ease-out';
const id = '6km8XoCWMNS';
const pulseAmount = 0.1;
const delay = 7750;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script14 = function()
{
  const target = object('5xtdl9FmA6v');
const duration = 750;
const easing = 'ease-out';
const id = '5uwc9EVDa1E';
const shrinkAmount = 0.2;
player.addForTriggers(
id,
target.animate([
{ scale: `${1 - shrinkAmount}` }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('5lWt4AF5c1b');
const duration = 750;
const easing = 'ease-out';
const id = '66IpNBlb6Aa';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  player.once(() => {
const target = object('68VqFsGKMdK');
const duration = 750;
const easing = 'ease-out';
const id = '6Uy7taZ9KJf';
const pulseAmount = 0.03;
const delay = 500;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script17 = function()
{
  player.once(() => {
const target = object('6LvZvkekbUN');
const duration = 750;
const easing = 'ease-out';
const id = '5pIxn1kRaxw';
const pulseAmount = 0.07;
const delay = 27750;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script18 = function()
{
  player.once(() => {
const target = object('6oqfjvi0xGE');
const duration = 750;
const easing = 'ease-out';
const id = '6MMiGqd9OaI';
const pulseAmount = 0.07;
const delay = 34250;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script19 = function()
{
  player.once(() => {
const target = object('5p7ZNRXEZ4E');
const duration = 750;
const easing = 'ease-out';
const id = '5q7jEGYELMU';
const pulseAmount = 0.07;
const delay = 0;
addToTimeline(
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', delay, duration, easing }
), id
);
});
}

window.Script20 = function()
{
  const target = object('5Y8thYiqTYS');
const duration = 750;
const easing = 'ease-out';
const id = '5yf0WBRcV56';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  const target = object('6JIVAOOgZc2');
const duration = 500;
const easing = 'ease-out';
const id = '6YVw8d8wNnN';
const pulseAmount = 0.1;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script22 = function()
{
  const target = object('6ChDLJ1fqBA');
const duration = 750;
const easing = 'ease-out';
const id = '6gx89PKcJVu';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script23 = function()
{
  const target = object('5iaxsCaIQOt');
const duration = 750;
const easing = 'ease-out';
const id = '66IpNBlb6Aa';
const pulseAmount = 0.03;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

window.Script24 = function()
{
  const target = object('6oeC9Db2Rnd');
const duration = 750;
const easing = 'ease-out';
const id = '6P4cWgzaPKZ';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate([
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }, { scale: `${1 + pulseAmount}` },
{ scale: '1' }
],
  { fill: 'forwards', duration, easing }
)
);
}

};

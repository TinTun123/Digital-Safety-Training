window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script25 = function()
{
  var player = GetPlayer();
var currentAudio = null;

// var path = document.getElementById('uniqueDomId-1572');
// var pathLength = path.getTotalLength();

// path.style.strokeDasharray = pathLength;
// path.style.strokeDashoffset = pathLength;

console.log("script ran");

setTimeout(function () {	

var audioElements = document.querySelectorAll('audio');    
audioElements.forEach(function(audioElement) {

    if (!audioElement.paused) {
    	currentAudio = audioElement;
    	console.log(currentAudio);
        }
    });
    
    if (currentAudio) {
            // Check if the metadata is loaded
            if (currentAudio.readyState > 0) {
                // Update progress immediately
                updateProgress(currentAudio);
                
                // Add an event listener to update progress as the audio plays
                currentAudio.addEventListener('timeupdate', function() {
                    updateProgress(currentAudio);
                });
            } else {
                // Wait for the metadata to be loaded
                currentAudio.addEventListener('loadedmetadata', function() {
                    updateProgress(currentAudio);
                    
                    // Add an event listener to update progress as the audio plays
                    currentAudio.addEventListener('timeupdate', function() {
                        updateProgress(currentAudio);
                    });
                });
            }
        } else {
            console.error('No currently playing audio element found.');
        }
        
}, 1000)

        
        
function updateProgress(audioElement) {

	var currentTime = audioElement.currentTime;
    var duration = audioElement.duration;
    
    var remainingTime = duration - currentTime;
    
    // var playedPercentage = (currentTime / duration) * 100;
    // var drawLength = pathLength * (playedPercentage / 100);
    
    // path.style.strokeDashoffset = pathLength - drawLength;
    var minutes = Math.floor(remainingTime / 60);
    var seconds = Math.floor(remainingTime % 60);
    var remainingTimeString = minutes + ":" + (seconds < 10 ? "0" + seconds : seconds); // Add leading zero for single-digit seconds
    
    player.SetVar("35timestemp" , remainingTimeString);
    
}
}

window.Script26 = function()
{
  var player = GetPlayer();
var currentAudio = null;

// var path = document.getElementById('uniqueDomId-1572');
// var pathLength = path.getTotalLength();

// path.style.strokeDasharray = pathLength;
// path.style.strokeDashoffset = pathLength;

console.log("script ran");

setTimeout(function () {	

var audioElements = document.querySelectorAll('audio');    
audioElements.forEach(function(audioElement) {

    if (!audioElement.paused) {
    	currentAudio = audioElement;
    	console.log(currentAudio);
        }
    });
    
    if (currentAudio) {
            // Check if the metadata is loaded
            if (currentAudio.readyState > 0) {
                // Update progress immediately
                updateProgress(currentAudio);
                
                // Add an event listener to update progress as the audio plays
                currentAudio.addEventListener('timeupdate', function() {
                    updateProgress(currentAudio);
                });
            } else {
                // Wait for the metadata to be loaded
                currentAudio.addEventListener('loadedmetadata', function() {
                    updateProgress(currentAudio);
                    
                    // Add an event listener to update progress as the audio plays
                    currentAudio.addEventListener('timeupdate', function() {
                        updateProgress(currentAudio);
                    });
                });
            }
        } else {
            console.error('No currently playing audio element found.');
        }
        
}, 1000)

        
        
function updateProgress(audioElement) {

	var currentTime = audioElement.currentTime;
    var duration = audioElement.duration;
    
    var remainingTime = duration - currentTime;
    
    // var playedPercentage = (currentTime / duration) * 100;
    // var drawLength = pathLength * (playedPercentage / 100);
    
    // path.style.strokeDashoffset = pathLength - drawLength;
    var minutes = Math.floor(remainingTime / 60);
    var seconds = Math.floor(remainingTime % 60);
    var remainingTimeString = minutes + ":" + (seconds < 10 ? "0" + seconds : seconds); // Add leading zero for single-digit seconds
    
    player.SetVar("39Timestemp" , remainingTimeString);
    
}
}

window.Script27 = function()
{
  var player = GetPlayer();
var currentAudio = null;

// var path = document.getElementById('uniqueDomId-1572');
// var pathLength = path.getTotalLength();

// path.style.strokeDasharray = pathLength;
// path.style.strokeDashoffset = pathLength;

console.log("script ran");

setTimeout(function () {	

var audioElements = document.querySelectorAll('video');    
audioElements.forEach(function(audioElement) {
	
    if (!audioElement.paused) {
    	currentAudio = audioElement;
    	console.log(currentAudio);
        }
    });
    
    if (currentAudio) {
    
			console.log("Found video");
            // Check if the metadata is loaded
            if (currentAudio.readyState > 0) {
                // Update progress immediately
                updateProgress(currentAudio);
                
                // Add an event listener to update progress as the audio plays
                currentAudio.addEventListener('timeupdate', function() {
                    updateProgress(currentAudio);
                });
            } else {
                // Wait for the metadata to be loaded
                currentAudio.addEventListener('loadedmetadata', function() {
                    updateProgress(currentAudio);
                    
                    // Add an event listener to update progress as the audio plays
                    currentAudio.addEventListener('timeupdate', function() {
                        updateProgress(currentAudio);
                    });
                });
            }
        } else {
            console.error('No currently playing audio element found.');
        }
        
}, 1000)

        
        
function updateProgress(audioElement) {

	var currentTime = audioElement.currentTime;
    var duration = audioElement.duration;
    
    var remainingTime = duration - currentTime;
    
    // var playedPercentage = (currentTime / duration) * 100;
    // var drawLength = pathLength * (playedPercentage / 100);
    
    // path.style.strokeDashoffset = pathLength - drawLength;
    var minutes = Math.floor(remainingTime / 60);
    var seconds = Math.floor(remainingTime % 60);
    var remainingTimeString = minutes + ":" + (seconds < 10 ? "0" + seconds : seconds); // Add leading zero for single-digit seconds
    
    player.SetVar("23Timestemp" , remainingTimeString);
    
}
}

window.Script28 = function()
{
  var player = GetPlayer();
var currentAudio = null;

// var path = document.getElementById('uniqueDomId-1572');
// var pathLength = path.getTotalLength();

// path.style.strokeDasharray = pathLength;
// path.style.strokeDashoffset = pathLength;

console.log("script ran");

setTimeout(function () {	

var audioElements = document.querySelectorAll('audio');    
audioElements.forEach(function(audioElement) {

    if (!audioElement.paused) {
    	currentAudio = audioElement;
    	console.log(currentAudio);
        }
    });
    
    if (currentAudio) {
            // Check if the metadata is loaded
            if (currentAudio.readyState > 0) {
                // Update progress immediately
                updateProgress(currentAudio);
                
                // Add an event listener to update progress as the audio plays
                currentAudio.addEventListener('timeupdate', function() {
                    updateProgress(currentAudio);
                });
            } else {
                // Wait for the metadata to be loaded
                currentAudio.addEventListener('loadedmetadata', function() {
                    updateProgress(currentAudio);
                    
                    // Add an event listener to update progress as the audio plays
                    currentAudio.addEventListener('timeupdate', function() {
                        updateProgress(currentAudio);
                    });
                });
            }
        } else {
            console.error('No currently playing audio element found.');
        }
        
}, 1000)

        
        
function updateProgress(audioElement) {

	var currentTime = audioElement.currentTime;
    var duration = audioElement.duration;
    
    var remainingTime = duration - currentTime;
    
    // var playedPercentage = (currentTime / duration) * 100;
    // var drawLength = pathLength * (playedPercentage / 100);
    
    // path.style.strokeDashoffset = pathLength - drawLength;
    var minutes = Math.floor(remainingTime / 60);
    var seconds = Math.floor(remainingTime % 60);
    var remainingTimeString = minutes + ":" + (seconds < 10 ? "0" + seconds : seconds); // Add leading zero for single-digit seconds
    
    player.SetVar("325audioTimestemp" , remainingTimeString);
    
}
}

};
